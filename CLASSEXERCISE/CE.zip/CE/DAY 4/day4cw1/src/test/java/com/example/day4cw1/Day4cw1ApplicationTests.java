package com.example.day4cw1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Day4cw1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
