package com.example.day1cw2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Day1cw2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
