package com.example.day5cw1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Day5cw1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
