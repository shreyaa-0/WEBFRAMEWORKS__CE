package com.example.day5cw2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Day5cw2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
